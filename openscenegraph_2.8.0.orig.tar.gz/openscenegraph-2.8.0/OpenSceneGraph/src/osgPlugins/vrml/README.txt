########################################################
# Replacement VRML plugin for  OpenSceneGraph.         #
# (C) J.Ciger B.Herbelin T.Abaci 2003,2004 VRlab EPFL  #
########################################################

- dependencies:
    OpenVRML (http://openvrml.org/)
    OpenSceneGraph (http://www.openscenegraph.org/)

CAUTION! 
This version of the plugin requires OpenVRML 0.14.3. Version 0.16.2 *WILL NOT* work!

